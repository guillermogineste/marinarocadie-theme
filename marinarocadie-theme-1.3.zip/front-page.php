<?php get_header(); ?>

	<main role="main">
		<section class="section section--single-image">
			<img class="homepage-image" src="<?php echo CFS()->get( 'homepage_image' ); ?>">
		</section>
	</main>

<?php get_footer(); ?>
